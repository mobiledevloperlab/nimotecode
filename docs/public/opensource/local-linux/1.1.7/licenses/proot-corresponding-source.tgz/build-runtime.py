#!/usr/bin/env python3
"""Reproducible Android-only runtime build. Update runtime.lock.json deliberately."""
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import tarfile
import zipfile

ROOT = Path(__file__).resolve().parent
LOCK = json.loads((ROOT / 'runtime.lock.json').read_text())
BUILD = ROOT / 'build'
OUT = ROOT / 'jniLibs'
ASSETS = ROOT / 'assets'


def run(*args, **kwargs):
    subprocess.run([str(arg) for arg in args], check=True, **kwargs)


def digest(path):
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def download(source, filename):
    path = BUILD / filename
    if not path.exists():
        part = path.with_suffix(path.suffix + '.part')
        run('curl', '--fail', '--location', '--proto', '=https', '--proto-redir', '=https',
            '--retry', '3', '--connect-timeout', '20', source['url'], '-o', part)
        part.replace(path)
    if digest(path) != source['sha256']:
        raise RuntimeError(f'Source checksum mismatch: {path}; remove the corrupt cache and retry')
    return path


def patch(path, old, new, count=1):
    text = path.read_text()
    if text.count(old) != count:
        raise RuntimeError(f'Upstream changed; review compatibility patch in {path.name}')
    path.write_text(text.replace(old, new))


def main():
    properties_file = ROOT.parent / 'local.properties'
    properties = properties_file.read_text().splitlines() if properties_file.exists() else []
    sdk = next((line.split('=', 1)[1] for line in properties if line.startswith('sdk.dir=')), None)
    sdk = sdk or os.environ.get('ANDROID_SDK_ROOT') or os.environ.get('ANDROID_HOME')
    if not sdk:
        raise RuntimeError('Configure sdk.dir or ANDROID_SDK_ROOT')
    host = {'Linux': 'linux-x86_64', 'Darwin': 'darwin-x86_64'}.get(platform.system())
    if not host:
        raise RuntimeError('Use Linux/macOS or the Android build CI for runtime compilation')
    tools = Path(sdk) / 'ndk' / LOCK['ndkVersion'] / 'toolchains/llvm/prebuilt' / host / 'bin'
    cc = tools / f'aarch64-linux-android{LOCK["apiLevel"]}-clang'
    if not cc.exists():
        raise RuntimeError(f'Install NDK {LOCK["ndkVersion"]} in {sdk}')
    if ASSETS.exists():
        shutil.rmtree(ASSETS)  # Generated only: prevent stale notices/metadata.
    for path in [BUILD, OUT, ASSETS / 'licenses']:
        path.mkdir(parents=True, exist_ok=True)
    proot_zip = download(LOCK['proot'], 'proot.zip')
    talloc_tar = download(LOCK['talloc'], 'talloc.tar.gz')
    for abi, triple in LOCK['abis'].items():
        abi_build = BUILD / abi
        out = OUT / abi
        abi_build.mkdir(parents=True, exist_ok=True)
        out.mkdir(parents=True, exist_ok=True)
        cc = tools / f'{triple}-linux-android{LOCK["apiLevel"]}-clang'
        proot = abi_build / ('proot-' + LOCK['proot']['version'])
        talloc = abi_build / ('talloc-' + LOCK['talloc']['version'])
        for path in [proot, talloc]:
            if path.exists():
                shutil.rmtree(path)  # Only generated, version-specific build sources.
        with zipfile.ZipFile(proot_zip) as archive:
            archive.extractall(abi_build)
        with tarfile.open(talloc_tar) as archive:
            archive.extractall(abi_build, filter='data')
        src = proot / 'src'
        ashmem = src / 'extension/ashmem_memfd/ashmem_memfd.c'
        ashmem.write_text('#include <string.h>\n' + ashmem.read_text())
        patch(src / 'tracee/event.c', 'PTRACE_O_TRACEEXIT);', 'PTRACE_O_TRACEEXIT | PTRACE_O_EXITKILL);')
        # Upstream deliberately ignores SIGTERM. Android Process.destroy() and the
        # parent-death guard use it, so treat it as an orderly tracee teardown request.
        patch(src / 'tracee/event.c', '\t\tcase SIGQUIT:\n', '\t\tcase SIGTERM:\n\t\tcase SIGQUIT:\n')
        # Android x86_64 app processes reject legacy rename(2). Use the
        # equivalent renameat(AT_FDCWD, ...) after path/extension translation.
        # Preserve the ORIGINAL register bank for extension bookkeeping.
        patch(src / 'syscall/enter.c', '\n\treturn status;\n}', '''
#if defined(__ANDROID__) && defined(__x86_64__)
\tif (status >= 0 && get_sysnum(tracee, CURRENT) == PR_rename) {
\t\tword_t old_path = peek_reg(tracee, CURRENT, SYSARG_1);
\t\tword_t new_path = peek_reg(tracee, CURRENT, SYSARG_2);
\t\tset_sysnum(tracee, PR_renameat);
\t\tpoke_reg(tracee, SYSARG_1, AT_FDCWD);
\t\tpoke_reg(tracee, SYSARG_2, old_path);
\t\tpoke_reg(tracee, SYSARG_3, AT_FDCWD);
\t\tpoke_reg(tracee, SYSARG_4, new_path);
\t}
\tif (status >= 0 && get_sysnum(tracee, CURRENT) == PR_unlink) {
\t\tword_t path = peek_reg(tracee, CURRENT, SYSARG_1);
\t\tset_sysnum(tracee, PR_unlinkat);
\t\tpoke_reg(tracee, SYSARG_1, AT_FDCWD);
\t\tpoke_reg(tracee, SYSARG_2, path);
\t\tpoke_reg(tracee, SYSARG_3, 0);
\t}
#endif
\treturn status;
}''')
        patch(src / 'syscall/exit.c',
              'if (syscall_number == PR_rename) {',
              'if (syscall_number == PR_rename && get_sysnum(tracee, MODIFIED) != PR_renameat) {')
        patch(src / 'GNUmakefile', '-z,noexecstack', '-z,noexecstack,-z,max-page-size=16384', count=2)
        makefile = src / 'GNUmakefile'
        makefile.write_text(makefile.read_text().replace('readelf -s', str(tools / 'llvm-readelf') + ' -s'))
        shutil.copyfile(ROOT / 'replace.h', talloc / 'replace.h')
        common = ['-O2', f'-ffile-prefix-map={abi_build}=/source']
        run(cc, *common, '-fPIC', '-I' + str(talloc), '-c', talloc / 'talloc.c', '-o', abi_build / 'talloc.o')
        run(tools / 'llvm-ar', 'rcsD', abi_build / 'libtalloc.a', abi_build / 'talloc.o')
        env = dict(os.environ, SOURCE_DATE_EPOCH='0')
        cpp = (f'-D_FILE_OFFSET_BITS=64 -D_GNU_SOURCE -DARG_MAX=131072 '
               f'-DVERSION=\\"{LOCK["proot"]["version"]}\\" -I. -I{talloc} '
               f'-ffile-prefix-map={abi_build}=/source')
        run('gmake' if platform.system() == 'Darwin' else 'make', '-C', src, '-j2',
            f'CC={cc}', f'STRIP={tools / "llvm-strip"}', f'OBJCOPY={tools / "llvm-objcopy"}',
            f'OBJDUMP={tools / "llvm-objdump"}', 'HAS_LOADER_32BIT=', 'GIT=false',
            'PROOT_UNBUNDLE_LOADER=/nonexistent', f'CPPFLAGS={cpp}',
            f'LDFLAGS=-L{abi_build} -ltalloc -Wl,-z,noexecstack,-z,max-page-size=16384', env=env)
        shutil.copyfile(src / 'proot', out / 'libproot.so')
        shutil.copyfile(src / 'loader/loader', out / 'libproot_loader.so')
        run(cc, *common, '-fPIE', '-pie', '-Wl,-z,max-page-size=16384', ROOT / 'launcher.c',
            '-o', out / 'libproot_launcher.so')
        for path in sorted(out.glob('*.so')):
            run(tools / 'llvm-strip', path)
            path.chmod(0o755)
    shutil.copyfile(proot / 'COPYING', ASSETS / 'licenses/proot.txt')
    shutil.copyfile(talloc / 'LICENSE', ASSETS / 'licenses/talloc.txt')
    metadata = dict(LOCK, binaries={str(path.relative_to(OUT)): {'sha256': digest(path), 'bytes': path.stat().st_size}
                                  for path in sorted(OUT.glob('*/*.so'))})
    (ASSETS / 'runtime-build.json').write_text(json.dumps(metadata, indent=2) + '\n')
    # Ship the actual corresponding source plus build inputs for our small patches.
    # This archive is license material, never executed or extracted by the app.
    with tarfile.open(ASSETS / 'licenses/proot-corresponding-source.tgz', 'w:gz') as source:
        for path, name in [(proot_zip, 'upstream/proot.zip'), (talloc_tar, 'upstream/talloc.tar.gz')]:
            source.add(path, arcname=name)
        for name in ['build-runtime.py', 'runtime.lock.json', 'replace.h', 'launcher.c']:
            source.add(ROOT / name, arcname=name)
    (ASSETS / 'licenses/runtime-notices.txt').write_text(
        'PRoot\nLicense: GPL-2.0-or-later\n'
        'Upstream: https://github.com/termux/proot\n'
        'Exact tag: v' + LOCK['proot']['version'] + '\n'
        'Source code URL: ' + LOCK['proot']['url'] + '\n'
        'NimoteCode patches: string.h declaration, SIGTERM teardown, PTRACE_O_EXITKILL, '
        '16 KiB ELF alignment, explicit NDK readelf and Android x86_64 renameat/unlinkat compatibility. '
        'Build script contains exact patches.\n'
        'Actual corresponding source and build inputs accompany this Android package in '
        'assets/licenses/proot-corresponding-source.tgz.\n'
        'PRoot is a separate executable; NimoteCode is not linked against it.\n\n'
        'talloc ' + LOCK['talloc']['version'] + '\nLicense: LGPL-3.0-or-later\n'
        'Source code URL: ' + LOCK['talloc']['url'] + '\n'
        'talloc is linked only into the independent PRoot executable.\n\n'
        + (ASSETS / 'licenses/proot.txt').read_text() + '\n'
        + (ASSETS / 'licenses/talloc.txt').read_text())
    print(json.dumps(metadata['binaries'], indent=2))


if __name__ == '__main__':
    main()
