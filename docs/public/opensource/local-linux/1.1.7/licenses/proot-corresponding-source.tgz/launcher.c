/* Android-only process parent-death guard. No JNI entrypoints. */
#include <sys/prctl.h>
#include <signal.h>
#include <unistd.h>
#include <stdio.h>

int main(int argc, char **argv) {
    if (argc < 2) return 125;
    pid_t parent = getppid();
    if (parent == 1 || prctl(PR_SET_PDEATHSIG, SIGTERM) != 0) return 125;
    if (getppid() != parent) return 125;
    printf("NIMOTE_PROOT_PID=%d\n", (int)getpid());
    fflush(stdout);
    execv(argv[1], argv + 1);
    perror("runtime exec");
    return 126;
}
