/* Bionic provides the libc functions needed by standalone talloc. This narrow
 * configuration replaces Samba's generated libreplace configuration, not talloc.
 * Target: Android API 24+, ARM64, NDK 28.2.13676358. */
#pragma once
#define _GNU_SOURCE 1
#include <assert.h>
#include <errno.h>
#include <limits.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#define HAVE_SYS_AUXV_H 1
#define HAVE_GETAUXVAL 1
#define HAVE_CONSTRUCTOR_ATTRIBUTE 1
#define HAVE_INTPTR_T 1
#define HAVE_VA_COPY 1
#define MIN(a, b) ((a) < (b) ? (a) : (b))
#define TALLOC_BUILD_VERSION_MAJOR 2
#define TALLOC_BUILD_VERSION_MINOR 4
#define TALLOC_BUILD_VERSION_RELEASE 3
